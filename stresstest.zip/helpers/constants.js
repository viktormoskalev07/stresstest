// export const baseUrl = "https://duel-api.smart-ui.pro";
export const baseUrl = "https://api.duelmasters.io";
// export const baseUrl = "https://digital.duelmasters.io";

// export const frontendUrl ="https://duel-master-git-duelmasters-old-api-config-duelmastersgg-s-team.vercel.app/"
// export const frontendUrl ="https://www.duelmasters.io/"
