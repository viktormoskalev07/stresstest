import {deleteUsers} from "./testsFunc/deleteScript.js"

deleteUsers()