import {app} from "./index.js";

app(" manually start");